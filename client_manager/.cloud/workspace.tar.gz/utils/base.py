BASE_DATA = {
    "API_BASE_URL": "http://192.168.1.33:5000",
    "ACCESS_KEY": "91ba6d98-079f-4601-939f-30ef872d084f",
    "SECRET_KEY": "277d66a89d2893a8f5e8a5b0dc50d0b023735aad39c32114d81d937b01a4f969",
    "ARVAN_CLOUD_ENDPOINT": "https://s3.ir-thr-at1.arvanstorage.com/",
    "BUCKET_NAME": "ccass1",
    "ATLAS_PASSWORD": "CCAss1_DBaas",
    "RABBITMQ_URL": "amqps://seuumisc:rKJKzpOFICHQ8384CAhDDvLMrrMH_l3w@shark.rmq.cloudamqp.com/seuumisc:5672"
}