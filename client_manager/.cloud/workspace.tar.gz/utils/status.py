class STATUS():
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"
